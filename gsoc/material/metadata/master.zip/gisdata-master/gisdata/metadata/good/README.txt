These metadata are subsets of the following sources:
 * http://www.sangis.org/
 * http://wiki.esipfed.org/index.php/ISO_19115_Metadata_for_Air_Quality
