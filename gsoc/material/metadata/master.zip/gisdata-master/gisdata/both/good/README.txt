These metadata are subsets of the following sources:
 * http://www.sangis.org/

